# WwN
Contains code and helper functions for projects and exams as a part of the "Working with Networks" course at IIM-A.